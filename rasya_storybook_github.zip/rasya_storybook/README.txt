RASYA'S STORYBOOK
=================

ISI FOLDER
- index.html : struktur website
- style.css  : tampilan dan desain
- script.js  : daftar cerpen, pencarian, dan tombol baca

CARA MEMBUKA DI SPCK EDITOR (ANDROID)
1. Ekstrak file ZIP ini.
2. Buka SPCK Editor.
3. Pilih Open Project / Import Project, lalu pilih folder rasya_storybook.
4. Pastikan index.html, style.css, dan script.js berada dalam satu folder.
5. Buka index.html lalu tekan Preview.

CARA UPLOAD KE GITHUB PAGES
1. Login ke https://github.com
2. Buat repository baru bernama rasya-storybook.
3. Pilih Public, lalu Create repository.
4. Upload index.html, style.css, dan script.js (serta README.txt jika mau) ke halaman utama repository.
   Jangan upload folder pembungkusnya; upload file-file di dalam folder.
5. Buka Settings > Pages.
6. Pada Build and deployment, pilih Deploy from a branch.
7. Pilih branch main dan folder /(root), lalu Save.
8. Tunggu proses selesai. Website akan tersedia di:
   https://USERNAME.github.io/rasya-storybook/

Ganti USERNAME dengan username GitHub milikmu.

CATATAN
- Website ini bisa dibuka publik setelah GitHub Pages aktif.
- Untuk mengubah cerita, edit bagian array "stories" di script.js.
- Ketiga file utama harus tetap berada di folder yang sama.
