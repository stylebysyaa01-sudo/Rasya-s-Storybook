const stories = [
  {
    id: 1, title: "Surat untuk Masa Depan", category: "Inspirasi",
    summary: "Sebuah surat kecil mengingatkan Dika untuk tidak menyerah pada mimpinya.",
    body: `Dika menemukan sebuah amplop cokelat di dalam laci meja belajarnya. Di bagian depan tertulis: Untuk Dika di masa depan.\n\nDengan rasa penasaran, ia membuka amplop itu. Isinya adalah surat yang pernah ia tulis sendiri saat masih kecil. Dalam surat itu, Dika bercerita tentang cita-citanya, tempat-tempat yang ingin ia kunjungi, dan janji untuk terus belajar.\n\nDika tersenyum. Beberapa hal memang belum tercapai, tetapi ia sadar bahwa dirinya sudah berjalan cukup jauh. Ia mengambil selembar kertas baru dan menulis surat untuk dirinya lima tahun mendatang.\n\nSejak hari itu, Dika belajar bahwa mimpi tidak harus diraih sekaligus. Satu langkah kecil setiap hari juga berarti kemajuan.`
  },
  {
    id: 2, title: "Teman di Bangku Belakang", category: "Persahabatan",
    summary: "Pertemuan sederhana di kelas berubah menjadi persahabatan yang berharga.",
    body: `Hari pertama di sekolah baru membuat Nara merasa canggung. Ia memilih duduk di bangku paling depan, sementara seorang anak bernama Bima duduk sendirian di belakang.\n\nSaat istirahat, Nara melihat Bima kesulitan memahami tugas matematika. Nara menawarkan bantuan. Awalnya mereka hanya membahas soal, tetapi obrolan berlanjut tentang buku, musik, dan permainan kesukaan.\n\nHari-hari berikutnya, mereka mulai belajar bersama. Bima membantu Nara mengenal lingkungan sekolah, sedangkan Nara membantu Bima lebih percaya diri saat mengerjakan tugas.\n\nNara akhirnya mengerti bahwa teman baik bisa ditemukan dari percakapan sederhana dan kemauan untuk saling membantu.`
  },
  {
    id: 3, title: "Cahaya di Ujung Jalan", category: "Kehidupan",
    summary: "Rani belajar melihat harapan dari hal-hal kecil di sekitarnya.",
    body: `Setiap sore, Rani melewati jalan kecil yang dipenuhi pepohonan. Belakangan ini ia sering merasa lelah karena banyak tugas yang harus diselesaikan.\n\nSuatu hari, hujan turun ketika Rani pulang. Ia berteduh di sebuah warung kecil. Pemilik warung menyuguhkan teh hangat dan berkata bahwa setelah hujan, udara biasanya terasa lebih segar.\n\nRani memperhatikan jalan yang basah dan cahaya matahari yang perlahan muncul dari balik awan. Pemandangan sederhana itu membuat pikirannya terasa lebih tenang.\n\nIa pulang dengan semangat baru. Masalah memang tidak langsung hilang, tetapi Rani tahu ia bisa menghadapinya satu per satu.`
  },
  {
    id: 4, title: "Perpustakaan Saat Hujan", category: "Petualangan",
    summary: "Sore yang hujan membawa seorang siswa pada buku penuh kejutan.",
    body: `Ketika hujan deras turun, Arga berlari ke perpustakaan sekolah. Ia berniat menunggu sampai hujan reda sambil mencari bacaan.\n\nDi rak paling pojok, ia menemukan buku tua tanpa judul. Halaman pertamanya berisi peta sederhana menuju taman kota. Arga mengenali gambar itu karena taman tersebut berada tidak jauh dari rumahnya.\n\nKeesokan harinya, Arga mengunjungi taman itu bersama kakaknya. Mereka menemukan papan kecil berisi pesan tentang menjaga kebersihan dan merawat tanaman.\n\nArga tertawa kecil. Buku itu ternyata bukan peta harta karun, melainkan ajakan untuk menemukan keindahan di sekitar mereka.`
  },
  {
    id: 5, title: "Pohon Mangga di Halaman", category: "Keluarga",
    summary: "Sebuah pohon mengajarkan keluarga tentang kesabaran dan kebersamaan.",
    body: `Di halaman rumah Sinta tumbuh pohon mangga yang ditanam oleh kakeknya. Setiap hari Sinta menyiramnya, meskipun pohon itu belum juga berbuah.\n\nKakek berkata bahwa tanaman membutuhkan waktu. Sinta pun terus merawatnya. Ia membersihkan rumput di sekitarnya dan memastikan pohon mendapat cukup air.\n\nBeberapa bulan kemudian, bunga-bunga kecil mulai bermunculan. Sinta sangat gembira dan memanggil seluruh keluarganya untuk melihat.\n\nSaat mangga pertama matang, mereka menikmatinya bersama. Sinta belajar bahwa hal baik sering membutuhkan kesabaran, perhatian, dan usaha yang dilakukan terus-menerus.`
  }
];

const bookContainer = document.getElementById("bookContainer");
const searchInput = document.getElementById("searchInput");
const emptyMessage = document.getElementById("emptyMessage");
const reader = document.getElementById("reader");
const readerCategory = document.getElementById("readerCategory");
const readerTitle = document.getElementById("readerTitle");
const readerBody = document.getElementById("readerBody");
const closeReader = document.getElementById("closeReader");

function renderStories(items) {
  bookContainer.innerHTML = "";
  emptyMessage.hidden = items.length !== 0;

  items.forEach((story) => {
    const card = document.createElement("article");
    card.className = "book-card";

    const cover = document.createElement("div");
    cover.className = `cover cover-${story.id}`;
    const coverTitle = document.createElement("span");
    coverTitle.textContent = story.title;
    cover.appendChild(coverTitle);

    const info = document.createElement("div");
    info.className = "book-info";

    const category = document.createElement("span");
    category.className = "category";
    category.textContent = story.category;

    const title = document.createElement("h3");
    title.textContent = story.title;

    const summary = document.createElement("p");
    summary.textContent = story.summary;

    const button = document.createElement("button");
    button.className = "read-button";
    button.type = "button";
    button.textContent = "Baca Cerita →";
    button.addEventListener("click", () => openStory(story.id));

    info.append(category, title, summary, button);
    card.append(cover, info);
    bookContainer.appendChild(card);
  });
}

function openStory(id) {
  const story = stories.find((item) => item.id === id);
  if (!story) return;

  readerCategory.textContent = story.category;
  readerTitle.textContent = story.title;
  readerBody.textContent = story.body;
  reader.hidden = false;
  reader.scrollIntoView({ behavior: "smooth", block: "start" });
}

function closeStory() {
  reader.hidden = true;
  document.getElementById("cerpen").scrollIntoView({ behavior: "smooth" });
}

searchInput.addEventListener("input", (event) => {
  const keyword = event.target.value.toLowerCase().trim();
  const filtered = stories.filter((story) =>
    story.title.toLowerCase().includes(keyword) ||
    story.category.toLowerCase().includes(keyword) ||
    story.summary.toLowerCase().includes(keyword)
  );
  renderStories(filtered);
});

closeReader.addEventListener("click", closeStory);
document.getElementById("year").textContent = new Date().getFullYear();
renderStories(stories);
